#include <stdio.h>

int main() {
    int choix:
    do {
        printf("1) Trier les numeros\n 2)Apprendre quel est le prochain numero\n)
        scanf(%d, )
    }
}