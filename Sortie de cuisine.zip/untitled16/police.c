#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "police.h"

void echange(appelRecord *a, appelRecord *b) {
    appelRecord temp = *a;
    *a = *b;
    *b = temp;
}

void triBulle(appelRecord records[])