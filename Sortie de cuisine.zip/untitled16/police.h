
#ifndef UNTITLED16_POLICE_H
#define UNTITLED16_POLICE_H
#define line_length 1000
#define records 1000

typedef struct {
    char numero[20];
    char nom[50];
    char prenom[50];
    char typeAppel[10];
} appelRecord;

void echanfe(appelRecord *a, appelRecord *b);
void triBulle(appelRecord records[], int n);
void triInsertion(appelRecord *records, int n);
void Tri();
#endif //UNTITLED16_POLICE_H